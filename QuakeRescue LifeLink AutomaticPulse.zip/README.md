# QuakeRescue LifeLink AutomaticPulse - Full Android + Wear OS Project (v6)

BLE-based emergency locator for disaster scenarios. Works like an "AirTag under the rubble" -
rescue teams scan with a BLE scanner (e.g. nRF Connect, LightBlue, BLE Scanner).

## What's new in v9 (this build)
- Fixed: SMS to emergency contacts now sends a FRESH GPS fix (requests a live location
  update, up to 8s wait) instead of only a possibly stale last-known location, falling
  back to the best last-known fix only if a fresh one can't be obtained in time.
- Added: onboarding now has a full test panel - test siren, test BLE signal (visible to
  any scanner app), and test emergency contact SMS (sends a real, clearly-marked TEST
  message with current GPS location to the saved contact so you can confirm it arrives).
- Fixed: the monthly test reminder notification (TestReminderReceiver) previously existed
  but was never actually scheduled anywhere - added ReminderScheduler, which arms a
  recurring 30-day AlarmManager reminder when onboarding finishes and re-arms it on every
  device reboot via BootReceiver, so the reminder now genuinely fires every month.

## What's new in v8 (this build)
- Stop control is now a deliberately hard two-stage hold, not a quick tap:
  Stage 1 requires holding the STOP button for 5 full seconds (up from 3s) with a
  visible fill-up progress bar; releasing early cancels with zero effect. Stage 2 opens
  a confirmation dialog that itself requires holding a second 'HOLD 3s TO CONFIRM STOP'
  button continuously - a single accidental tap can no longer silence the alarm, which
  matters for a disoriented or shocked survivor.
- Screen brightness now rises to a clearly readable level (not full brightness) the
  instant the phone's screen is turned on/unlocked during an active alarm - so a rescuer
  or the survivor themselves can actually see and use the hold-to-stop control - then
  automatically dims back to 1% a few seconds after the screen turns off again.

## What's new in v7 (this build)
- Fixed: earthquake keyword list now covers all 9 shipped languages (Swedish, English,
  Spanish, Chinese, Indonesian, Japanese, Thai, Greek, Nepali) plus accent-insensitive
  matching, so institutional WEA/ETWS alerts are recognized regardless of language -
  no more false negatives from untranslated keywords.
- Fixed/clarified: double-alarm protection is now explicit and documented in code
  (EarthquakeState). If the beacon is already ACTIVE or a countdown is already running,
  ANY later trigger - including a delayed institutional alert arriving after the phone's
  own shake detector already started the alarm - is dropped immediately and can never
  restart or interfere with an alarm already in progress. Only an explicit
  "I AM SAFE" tap resets the system.
- Clarified: shake detection uses a genuinely sleeping two-stage design, identical in
  principle to Google's own earthquake network - a low-power hardware trigger sensor
  (Significant Motion) stays asleep with near-zero battery draw until real large motion
  occurs, only then briefly waking the accelerometer for a few seconds to confirm.

## What's new in v6 (this build)
- Temporary Bluetooth device name during an active alarm only (BluetoothNameManager):
  when the beacon activates, the phone's Bluetooth adapter name is changed to
  "SOS QuakeRescue Signal" so any BLE scanner shows this plain, readable label
  directly in scan results - no dedicated app needed on the rescuer's side.
  The original Bluetooth name (used e.g. when pairing with a car) is saved
  beforehand and automatically restored the moment the beacon stops, so the
  phone's everyday name is never permanently changed - only during the actual
  alarm window, for privacy reasons.
- Offset alarm timing: the audible siren plays 30 seconds after each BLE pulse
  starts, rather than at the same instant. This spreads the two signals apart
  in time instead of firing them simultaneously, increasing the chances that a
  passerby or rescue team notices at least one of them at any given moment.
- Five-tier adaptive battery profile (BatteryMonitor): 50-100% -> 15 min cycle/2 min BLE/alarm every cycle;
  30-50% -> 20 min/2 min/every cycle; 15-30% -> 30 min/1 min/every 2nd cycle;
  5-15% -> 45 min/1 min/every 3rd cycle; 0-5% -> 60 min/1 min/every 4th cycle.
- Two-stage low-power motion detection (AccelerometerEarthquakeDetector).
- Double-alarm protection (EarthquakeState).
- Smart screen backlight (EmergencyPowerManager).
- Two-step safe stop (MainActivity): hold 3s then confirm dialog.
- Opt-in SMS with two optional emergency contacts (LocationHelper + OnboardingActivity):
  OFF by default, both phone number fields optional, user can leave both blank
  for full privacy.

## What rescue teams see when scanning
Any standard BLE scanner app (nRF Connect, LightBlue, BLE Scanner, or professional
equipment) shows the device broadcasting under the name "SOS QuakeRescue Signal"
during an active alarm - a plain label anyone can recognize and search for,
without needing to know any technical identifiers in advance. This name is only
visible while the beacon is actively pulsing; the rest of the time the phone
keeps its normal Bluetooth name.

## Detection channels
- WEA (EU/US) and ETWS/J-Alert (Japan) cell broadcast.
- On-device two-stage shake detection - works fully offline, no Google Earthquake Alerts used.

## Privacy
- Bluetooth name change is temporary and automatic - only during an active alarm,
  reverted immediately when the beacon stops.
- SMS is opt-in, off by default, up to two optional emergency contacts.
- Location is read only once, at activation - no continuous tracking.
- No server communication except the optional SMS. No analytics/ads SDK.

## Modules
- `app`: Android phone app.
- `wear`: Wear OS companion app.

## Language folders
values, values-en, values-es, values-zh, values-in, values-ja, values-th, values-el, values-ne.

## Open in Android Studio
1. Unzip the project.
2. File -> Open -> select the project root folder.
3. Wait for Gradle sync.
4. Run `app` on a phone/emulator, run `wear` on a Wear OS device/emulator.

## Permissions requested
Bluetooth advertise/connect, fine/coarse location, SEND_SMS (only if enabled),
POST_NOTIFICATIONS, RECEIVE_BOOT_COMPLETED, VIBRATE, WAKE_LOCK, WRITE_SETTINGS,
REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, RECEIVE_EMERGENCY_BROADCAST.
