package com.emergencybeacon

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.MotionEvent
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView

/**
 * Stopping an active alarm is intentionally a TWO-STAGE, hold-based process,
 * made deliberately hard to trigger by accident or confusion - because a
 * person who is shocked, disoriented, or trapped under rubble must never be
 * able to silence their own rescue signal with a stray touch, a knee bump,
 * or a panicked tap. Both stages require a sustained, continuous hold - a
 * quick or interrupted press has zero effect and simply resets.
 *
 * Stage 1: hold the STOP button for 5 full seconds (up from an earlier
 *          3-second design) with a visible fill-up progress bar as feedback.
 *          Releasing early cancels immediately and resets progress to zero.
 * Stage 2: a confirmation dialog appears that itself requires holding a
 *          second "HOLD TO CONFIRM" button for 3 more continuous seconds
 *          (not a simple tap) - so even someone who fumbles through Stage 1
 *          cannot silence the alarm with one more accidental tap. Tapping
 *          outside the dialog, pressing back, or releasing early does nothing.
 *
 * Starting the beacon, by contrast, remains a single ordinary tap - an
 * accidental activation is harmless, while an accidental deactivation during
 * a real emergency could be fatal.
 */
class MainActivity : Activity() {

    private var countDownTimer: CountDownTimer? = null
    private var stage1Handler: Handler? = null
    private var stage1Runnable: Runnable? = null
    private var stage1Progress: CountDownTimer? = null
    private var beaconRunning = false

    private val stage1HoldMs = 5000L
    private val stage2HoldMs = 3000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val statusText = findViewById<TextView>(R.id.statusText)
        val stopButton = findViewById<Button>(R.id.stopButton)
        val stopProgress = findViewById<ProgressBar>(R.id.stopHoldProgress)
        stopProgress.max = stage1HoldMs.toInt()
        stopProgress.progress = 0

        findViewById<Button>(R.id.startButton).setOnClickListener {
            startService(Intent(this, BeaconService::class.java).putExtra("reason", "manual"))
            beaconRunning = true
            statusText.text = getString(R.string.status_active)
        }

        stopButton.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (!beaconRunning) return@setOnTouchListener true
                    startStage1Hold(stopProgress)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    cancelStage1Hold(stopProgress)
                    true
                }
                else -> false
            }
        }

        findViewById<Button>(R.id.safeButton).setOnClickListener {
            countDownTimer?.cancel()
            EarthquakeState.reset()
            statusText.text = getString(R.string.status_inactive)
        }

        findViewById<Button>(R.id.activateNowButton).setOnClickListener {
            countDownTimer?.cancel()
            startService(Intent(this, BeaconService::class.java).putExtra("reason", "activate_now"))
            beaconRunning = true
            statusText.text = getString(R.string.status_active)
        }

        if (intent.hasExtra("trigger_source")) {
            startSafetyCountdown()
        }

        AccelerometerEarthquakeDetector.resume(this)
    }

    private fun startStage1Hold(progressBar: ProgressBar) {
        stage1Handler = Handler(Looper.getMainLooper())

        // Visual feedback: progress bar fills over the full 5-second hold.
        // Any release before completion cancels this timer with zero effect.
        stage1Progress = object : CountDownTimer(stage1HoldMs, 50L) {
            override fun onTick(millisUntilFinished: Long) {
                progressBar.progress = (stage1HoldMs - millisUntilFinished).toInt()
            }
            override fun onFinish() {
                progressBar.progress = stage1HoldMs.toInt()
            }
        }.start()

        stage1Runnable = Runnable { showStage2ConfirmationDialog(progressBar) }
        stage1Handler?.postDelayed(stage1Runnable!!, stage1HoldMs)
    }

    private fun cancelStage1Hold(progressBar: ProgressBar) {
        stage1Runnable?.let { stage1Handler?.removeCallbacks(it) }
        stage1Progress?.cancel()
        progressBar.progress = 0
    }

    private fun showStage2ConfirmationDialog(progressBar: ProgressBar) {
        progressBar.progress = 0

        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_confirm_stop, null)
        val confirmHoldButton = dialogView.findViewById<Button>(R.id.confirmHoldButton)
        val confirmProgress = dialogView.findViewById<ProgressBar>(R.id.confirmHoldProgress)
        confirmProgress.max = stage2HoldMs.toInt()

        val dialog = AlertDialog.Builder(this)
            .setTitle(getString(R.string.confirm_stop_title))
            .setMessage(getString(R.string.confirm_stop_message))
            .setView(dialogView)
            .setNegativeButton(getString(R.string.cancel_button), null)
            .setCancelable(false)
            .create()

        var confirmHandler: Handler? = null
        var confirmRunnable: Runnable? = null
        var confirmProgressTimer: CountDownTimer? = null

        confirmHoldButton.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    confirmHandler = Handler(Looper.getMainLooper())
                    confirmProgressTimer = object : CountDownTimer(stage2HoldMs, 50L) {
                        override fun onTick(millisUntilFinished: Long) {
                            confirmProgress.progress = (stage2HoldMs - millisUntilFinished).toInt()
                        }
                        override fun onFinish() {
                            confirmProgress.progress = stage2HoldMs.toInt()
                        }
                    }.start()
                    confirmRunnable = Runnable {
                        stopService(Intent(this, BeaconService::class.java))
                        beaconRunning = false
                        EarthquakeState.reset()
                        AccelerometerEarthquakeDetector.resume(this)
                        findViewById<TextView>(R.id.statusText).text = getString(R.string.status_inactive)
                        dialog.dismiss()
                    }
                    confirmHandler?.postDelayed(confirmRunnable!!, stage2HoldMs)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    confirmRunnable?.let { confirmHandler?.removeCallbacks(it) }
                    confirmProgressTimer?.cancel()
                    confirmProgress.progress = 0
                    true
                }
                else -> false
            }
        }

        dialog.show()
    }

    private fun startSafetyCountdown() {
        val statusText = findViewById<TextView>(R.id.statusText)
        countDownTimer = object : CountDownTimer(5 * 60_000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                val minutes = millisUntilFinished / 60000
                val seconds = (millisUntilFinished / 1000) % 60
                statusText.text = getString(R.string.auto_start_in, minutes, seconds)
            }

            override fun onFinish() {
                startService(Intent(this@MainActivity, BeaconService::class.java).putExtra("reason", "auto"))
                beaconRunning = true
                statusText.text = getString(R.string.status_active)
            }
        }.start()
    }

    override fun onDestroy() {
        countDownTimer?.cancel()
        stage1Runnable?.let { stage1Handler?.removeCallbacks(it) }
        stage1Progress?.cancel()
        super.onDestroy()
    }
}
