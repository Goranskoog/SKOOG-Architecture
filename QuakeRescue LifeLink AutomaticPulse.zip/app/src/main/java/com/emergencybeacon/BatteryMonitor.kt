package com.emergencybeacon

import android.content.Context
import android.os.BatteryManager

data class BatteryProfile(
    val cycleMinutes: Long,
    val bleOnMinutes: Long,
    val alarmEveryNCycles: Int
)

object BatteryMonitor {
    fun getBatteryPercent(context: Context): Int {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    fun getProfile(context: Context): BatteryProfile {
        val pct = getBatteryPercent(context)
        return when {
            pct > 50 -> BatteryProfile(15, 2, 1)
            pct > 30 -> BatteryProfile(20, 2, 1)
            pct > 15 -> BatteryProfile(30, 1, 2)
            pct > 5  -> BatteryProfile(45, 1, 3)
            else     -> BatteryProfile(60, 1, 4)
        }
    }
}
