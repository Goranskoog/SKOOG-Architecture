package com.emergencybeacon

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

/**
 * Schedules the recurring monthly reminder notification (TestReminderReceiver)
 * that prompts the user to re-test the siren, BLE signal, and emergency
 * contact SMS. Without this scheduler the receiver would exist in the
 * manifest but never actually fire - this object is what makes the "test
 * everything once a month" promise real.
 *
 * Scheduled both right after onboarding finishes, and again on every device
 * boot (via BootReceiver), so the reminder survives reboots and is never
 * silently lost.
 */
object ReminderScheduler {
    private const val THIRTY_DAYS_MS = 30L * 24 * 60 * 60 * 1000

    fun scheduleMonthlyReminder(context: Context) {
        val intent = Intent(context, TestReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, 2001, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val triggerAt = System.currentTimeMillis() + THIRTY_DAYS_MS
        try {
            alarmManager.setInexactRepeating(
                AlarmManager.RTC_WAKEUP, triggerAt, THIRTY_DAYS_MS, pendingIntent
            )
        } catch (e: Exception) { }
    }
}
