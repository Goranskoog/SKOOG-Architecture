package com.emergencybeacon

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Listens for WEA (US/EU), ETWS/J-Alert (Japan) and other national cell
 * broadcast emergency channels. Keyword list below covers every language the
 * app ships in, so an institutional alert is recognized no matter which
 * country/language it arrives in - not just English/Japanese.
 *
 * Double-alarm protection: this receiver NEVER decides on its own whether to
 * start a new countdown. It always calls EarthquakeState.triggerCountdown(),
 * which internally ignores the request completely if the beacon is already
 * ACTIVE (person already confirmed injured/trapped and the signal is already
 * transmitting) or if a countdown is already running. This guarantees that a
 * later institutional message - arriving after the phone's own shake
 * detection already started the alarm - can NEVER restart, extend, or
 * interfere with an alarm that is already in progress. Only an explicit
 * "I AM SAFE" tap resets the system back to listening mode.
 */
class EarthquakeReceiver : BroadcastReceiver() {

    // Earthquake keywords covering every shipped language: Swedish (default),
    // English, Spanish, Chinese, Indonesian, Japanese, Thai, Greek, Nepali.
    private val earthquakeKeywords = listOf(
        // Swedish
        "jordbavning", "jordskalv",
        // English
        "earthquake", "seismic", "quake",
        // Spanish
        "terremoto", "sismo", "sismico", "seismo",
        // Chinese (simplified + traditional)
        "\u5730\u9707",
        // Indonesian
        "gempa", "gempa bumi",
        // Japanese
        "\u5730\u9707", "jishin",
        // Thai
        "\u0e41\u0e1c\u0e48\u0e19\u0e14\u0e34\u0e19\u0e44\u0e2b\u0e27",
        // Greek
        "\u03c3\u03b5\u03b9\u03c3\u03bc\u03cc\u03c2", "seismos",
        // Nepali
        "\u092d\u0942\u0915\u0902\u092a", "bhukampa"
    )

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (!action.contains("SMS")) return

        val extras = intent.extras
        val rawMessage = extras?.getString("message", "") ?: ""
        val messageBody = normalize(rawMessage)

        // Cell broadcast channels used here (WEA_EMERGENCY_CB / SMS_CB) are
        // dedicated emergency-alert channels - if the OS delivered a message
        // on this channel but stripped/omitted readable text, we still treat
        // it as a genuine alert rather than silently dropping it.
        val isEarthquake = messageBody.isEmpty() || earthquakeKeywords.any { messageBody.contains(it) }

        if (isEarthquake) {
            EarthquakeState.triggerCountdown(context, "cell_broadcast")
        }
    }

    /** Lowercases and strips diacritics so keyword matching also catches
     * accented variants (e.g. "jordbävning" -> "jordbavning"). */
    private fun normalize(text: String): String {
        val lower = text.lowercase()
        val decomposed = java.text.Normalizer.normalize(lower, java.text.Normalizer.Form.NFD)
        return decomposed.replace(Regex("\\p{Mn}+"), "")
    }
}
