package com.emergencybeacon

import android.content.Context
import android.content.Intent

/**
 * Central guard against double alarms. Once the beacon is ACTIVE (person
 * confirmed unsafe, or the 5-minute countdown finished automatically), any
 * further trigger from ANY source - a late institutional alert (WEA/ETWS),
 * a second shake event, or a repeated aftershock notification - is silently
 * ignored. The alarm can only be reset by an explicit "I AM SAFE" action from
 * the user (see MainActivity / BeaconService onDestroy). This means: if the
 * phone's own shake detector already started the countdown or the beacon,
 * and an institutional message about the same earthquake arrives afterwards,
 * it will NOT create a new countdown, restart the existing one, or re-trigger
 * anything - it is dropped immediately by the check below.
 */
object EarthquakeState {

    enum class Status { IDLE, COUNTDOWN, ACTIVE }

    @Volatile
    var status: Status = Status.IDLE
        private set

    fun triggerCountdown(context: Context, source: String) {
        synchronized(this) {
            // If a countdown is already running OR the beacon is already
            // actively transmitting, ignore this trigger completely -
            // regardless of which source it came from (shake sensor,
            // WEA/ETWS cell broadcast, or any future channel).
            if (status != Status.IDLE) return
            status = Status.COUNTDOWN
        }
        val intent = Intent(context, MainActivity::class.java)
        intent.putExtra("trigger_source", source)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    fun markActive() { status = Status.ACTIVE }

    /** Only called when the user explicitly confirms "I AM SAFE". This is the
     * ONLY way the system returns to listening mode after an alarm. */
    fun reset() { status = Status.IDLE }
}
