package com.emergencybeacon

import android.media.AudioManager
import android.media.ToneGenerator

object SosAudioManager {
    private var toneGenerator: ToneGenerator? = null

    fun playSiren() {
        try {
            toneGenerator?.release()
            toneGenerator = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 3000)
        } catch (e: Exception) { }
    }

    fun stop() {
        toneGenerator?.stopTone()
        toneGenerator?.release()
        toneGenerator = null
    }
}
