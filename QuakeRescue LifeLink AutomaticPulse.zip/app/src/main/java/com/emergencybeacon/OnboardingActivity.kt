package com.emergencybeacon

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast

/**
 * Onboarding includes a dedicated test panel so the user can verify every
 * critical function BEFORE relying on it in a real emergency:
 * - Test siren: plays the actual alarm sound.
 * - Test BLE signal: briefly starts real BLE advertising exactly as the
 *   live beacon would, so a scanner app can confirm it is visible.
 * - Test emergency contact SMS: sends a real SMS (clearly marked "TEST")
 *   with the current GPS location to the saved emergency contact(s), so the
 *   user can confirm the numbers are correct and the contact actually
 *   receives it - without waiting for a real disaster to find out.
 *
 * A monthly reminder (ReminderScheduler) is also armed once onboarding
 * completes, prompting the user every 30 days to repeat this same test.
 */
class OnboardingActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)

        val prefs = getSharedPreferences("beacon_prefs", MODE_PRIVATE)
        val smsToggle = findViewById<CheckBox>(R.id.smsEnabledCheckbox)
        val contact1Input = findViewById<EditText>(R.id.contactInput1)
        val contact2Input = findViewById<EditText>(R.id.contactInput2)

        smsToggle.isChecked = prefs.getBoolean("sms_enabled", false)
        contact1Input.setText(prefs.getString("emergency_contact_1", ""))
        contact2Input.setText(prefs.getString("emergency_contact_2", ""))

        fun saveContactPrefs() {
            prefs.edit()
                .putBoolean("sms_enabled", smsToggle.isChecked)
                .putString("emergency_contact_1", contact1Input.text.toString())
                .putString("emergency_contact_2", contact2Input.text.toString())
                .apply()
        }

        findViewById<Button>(R.id.testSirenButton).setOnClickListener {
            SosAudioManager.playSiren()
            Toast.makeText(this, getString(R.string.test_siren_playing), Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.testBleButton).setOnClickListener {
            startService(Intent(this, BeaconService::class.java).putExtra("mode", "test"))
            Toast.makeText(this, getString(R.string.test_ble_started), Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.testContactButton).setOnClickListener {
            saveContactPrefs()
            LocationHelper.sendEmergencySms(this, isTest = true)
            Toast.makeText(this, getString(R.string.test_sms_sent), Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.saveContactButton).setOnClickListener {
            saveContactPrefs()
            Toast.makeText(this, getString(R.string.settings_saved), Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.batteryOptButton).setOnClickListener {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        }

        findViewById<Button>(R.id.enableShakeButton).setOnClickListener {
            AccelerometerEarthquakeDetector.resume(this)
        }

        findViewById<Button>(R.id.dndOverrideButton).setOnClickListener {
            DoNotDisturbOverride.requestPolicyAccess(this)
        }

        findViewById<Button>(R.id.finishOnboardingButton).setOnClickListener {
            saveContactPrefs()
            ReminderScheduler.scheduleMonthlyReminder(this)
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
