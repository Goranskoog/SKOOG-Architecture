package com.emergencybeacon

import android.app.Service
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelUuid
import android.os.PowerManager

/**
 * While the beacon is active, the Bluetooth adapter name is temporarily changed
 * to "SOS QuakeRescue Signal" (see BluetoothNameManager) so rescue teams scanning
 * with any standard BLE scanner app see a plain, readable label instead of the
 * phone's normal device name. The original name is restored automatically as
 * soon as the beacon stops, so the phone's everyday Bluetooth name (used e.g.
 * when pairing with a car) is never permanently changed - only during an
 * actual active alarm.
 *
 * The BLE advertising and the audible siren are intentionally offset (not
 * synchronized): the siren plays 30 seconds after each BLE pulse starts, so
 * the two signals do not always occur at the exact same moment. This spreads
 * out detection opportunities over time instead of concentrating them, making
 * the beacon easier to notice overall.
 */
class BeaconService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var advertiser: BluetoothLeAdvertiser? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var running = false
    private var cycleCount = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        running = true
        cycleCount = 0
        EarthquakeState.markActive()
        AccelerometerEarthquakeDetector.pause()
        acquireWakeLock()
        EmergencyPowerManager.dimScreen(this)
        BluetoothNameManager.applyAlarmName(this)
        DoNotDisturbOverride.overrideForAlarm(this)
        LocationHelper.sendEmergencySms(this)
        WearSyncManager.notifyWatch(this)
        startCycle()
        return START_STICKY
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "QuakeRescue::BeaconWakeLock")
        wakeLock?.acquire(60 * 60 * 1000L)
    }

    private fun startCycle() {
        if (!running) return
        val profile = BatteryMonitor.getProfile(this)
        cycleCount++

        startAdvertising()
        if (cycleCount % profile.alarmEveryNCycles == 0) {
            handler.postDelayed({ SosAudioManager.playSiren() }, 30_000)
        }
        handler.postDelayed({ stopAdvertising() }, profile.bleOnMinutes * 60_000L)
        handler.postDelayed({ startCycle() }, profile.cycleMinutes * 60_000L)
    }

    private fun startAdvertising() {
        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = bluetoothManager.adapter ?: return
        if (!adapter.isEnabled) return
        advertiser = adapter.bluetoothLeAdvertiser ?: return

        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .setConnectable(false)
            .build()

        val data = AdvertiseData.Builder()
            .addServiceUuid(ParcelUuid(BeaconIdentity.getBeaconUuid(this)))
            .setIncludeDeviceName(true)
            .build()

        try {
            advertiser?.startAdvertising(settings, data, advertiseCallback)
        } catch (e: SecurityException) { }
    }

    private fun stopAdvertising() {
        try {
            advertiser?.stopAdvertising(advertiseCallback)
        } catch (e: SecurityException) { }
        SosAudioManager.stop()
    }

    private val advertiseCallback = object : AdvertiseCallback() {}

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        stopAdvertising()
        EmergencyPowerManager.restoreScreen(this)
        BluetoothNameManager.restoreOriginalName(this)
        DoNotDisturbOverride.restoreAfterAlarm(this)
        wakeLock?.let { if (it.isHeld) it.release() }
        EarthquakeState.reset()
        super.onDestroy()
    }
}
