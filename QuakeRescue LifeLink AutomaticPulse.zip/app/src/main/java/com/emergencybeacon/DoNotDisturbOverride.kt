package com.emergencybeacon

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.provider.Settings

/**
 * Automatically overrides Do Not Disturb, Silent Mode, and Bedtime Mode
 * (which on Android is implemented as a Do Not Disturb automatic rule) so the
 * siren is always audible during an active emergency alarm - this is
 * explicitly permitted by Android via the Notification Policy Access API,
 * as long as the user has granted the app that special access once.
 *
 * The override is applied ONLY while the beacon alarm is active, and the
 * user's original settings (interruption filter + alarm stream volume) are
 * restored automatically the moment the alarm stops - so normal Do Not
 * Disturb / Bedtime behavior returns to exactly how the user had it as soon
 * as the emergency is over.
 */
object DoNotDisturbOverride {
    private var savedInterruptionFilter: Int? = null
    private var savedAlarmVolume: Int? = null

    fun hasPolicyAccess(context: Context): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return nm.isNotificationPolicyAccessGranted
    }

    fun requestPolicyAccess(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) { }
    }

    fun overrideForAlarm(context: Context) {
        // Silences Do Not Disturb / Silent Mode / Bedtime Mode for the
        // duration of the alarm only - Bedtime Mode is implemented on
        // Android as a Do Not Disturb automatic rule, so overriding the
        // interruption filter covers all three simultaneously.
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted) {
                savedInterruptionFilter = nm.currentInterruptionFilter
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            }
        } catch (e: Exception) { }

        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            savedAlarmVolume = am.getStreamVolume(AudioManager.STREAM_ALARM)
            val maxVolume = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(AudioManager.STREAM_ALARM, maxVolume, 0)
        } catch (e: Exception) { }
    }

    fun restoreAfterAlarm(context: Context) {
        try {
            savedInterruptionFilter?.let { filter ->
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (nm.isNotificationPolicyAccessGranted) {
                    nm.setInterruptionFilter(filter)
                }
            }
        } catch (e: Exception) { }
        savedInterruptionFilter = null

        try {
            savedAlarmVolume?.let { vol ->
                val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.setStreamVolume(AudioManager.STREAM_ALARM, vol, 0)
            }
        } catch (e: Exception) { }
        savedAlarmVolume = null
    }
}
