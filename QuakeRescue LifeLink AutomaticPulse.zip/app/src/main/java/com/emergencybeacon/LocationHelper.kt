package com.emergencybeacon

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Looper
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Sends the freshest possible GPS position to emergency contacts when the
 * beacon activates - not just whatever stale location happened to be cached
 * from hours or days ago.
 *
 * Strategy: request a single fresh location update from the GPS provider
 * (falling back to network provider if GPS is unavailable) and wait up to
 * 8 seconds for a fix. If a fresh fix arrives in time, that is used. If it
 * times out (e.g. weak signal under rubble), the best last-known location
 * across all providers is used instead as a fallback - so a message is
 * always sent, just with the most accurate position available.
 */
object LocationHelper {

    @SuppressLint("MissingPermission")
    fun getFreshLocationString(context: Context): String {
        val hasFine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!hasFine && !hasCoarse) return "location unavailable"

        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val provider = when {
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            else -> null
        }

        var freshResult: String? = null
        if (provider != null) {
            val latch = CountDownLatch(1)
            val listener = object : android.location.LocationListener {
                override fun onLocationChanged(location: android.location.Location) {
                    freshResult = "https://maps.google.com/?q=${'$'}{location.latitude},${'$'}{location.longitude}"
                    latch.countDown()
                }
                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(p: String?, s: Int, e: android.os.Bundle?) {}
                override fun onProviderEnabled(p: String) {}
                override fun onProviderDisabled(p: String) {}
            }
            try {
                lm.requestSingleUpdate(provider, listener, Looper.getMainLooper())
                latch.await(8, TimeUnit.SECONDS)
                lm.removeUpdates(listener)
            } catch (e: Exception) { }
        }

        if (freshResult != null) return freshResult!!

        // Fallback: best last-known fix across all providers if a fresh
        // GPS fix could not be obtained in time.
        val providers = lm.getProviders(true)
        var best: android.location.Location? = null
        for (p in providers) {
            val loc = lm.getLastKnownLocation(p)
            if (loc != null && (best == null || loc.accuracy < best!!.accuracy)) {
                best = loc
            }
        }
        return best?.let { "https://maps.google.com/?q=${'$'}{it.latitude},${'$'}{it.longitude}" } ?: "location unavailable"
    }

    fun sendEmergencySms(context: Context, isTest: Boolean = false) {
        val prefs = context.getSharedPreferences("beacon_prefs", Context.MODE_PRIVATE)

        val smsEnabled = prefs.getBoolean("sms_enabled", false)
        if (!smsEnabled) return

        val contact1 = prefs.getString("emergency_contact_1", null)
        val contact2 = prefs.getString("emergency_contact_2", null)
        val contacts = listOfNotNull(contact1, contact2).filter { it.isNotBlank() }
        if (contacts.isEmpty()) return

        val hasSms = ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
        if (!hasSms) return

        val location = getFreshLocationString(context)
        val beaconId = BeaconIdentity.getShortBeaconId(context)
        val message = if (isTest) {
            context.getString(R.string.sms_test_body, location, beaconId)
        } else {
            context.getString(R.string.sms_emergency_body, location, beaconId)
        }

        try {
            val smsManager = context.getSystemService(SmsManager::class.java)
            for (contact in contacts) {
                smsManager.sendTextMessage(contact, null, message, null, null)
            }
        } catch (e: Exception) { }
    }
}
