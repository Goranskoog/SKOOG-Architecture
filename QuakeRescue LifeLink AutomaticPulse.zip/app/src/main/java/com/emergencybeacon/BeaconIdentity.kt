package com.emergencybeacon

import android.content.Context
import java.util.UUID

object BeaconIdentity {
    private const val FAMILY_SIGNATURE = "F17A2B3C-QRLA-4D5E-8F90-"

    fun getBeaconUuid(context: Context): UUID {
        val prefs = context.getSharedPreferences("beacon_prefs", Context.MODE_PRIVATE)
        var suffix = prefs.getString("device_suffix", null)
        if (suffix == null) {
            suffix = UUID.randomUUID().toString().substring(0, 12)
            prefs.edit().putString("device_suffix", suffix).apply()
        }
        return UUID.fromString(FAMILY_SIGNATURE + suffix)
    }

    fun getShortBeaconId(context: Context): String {
        return getBeaconUuid(context).toString().takeLast(8).uppercase()
    }
}
