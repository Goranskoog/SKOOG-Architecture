package com.emergencybeacon

import android.bluetooth.BluetoothAdapter
import android.content.Context

/**
 * Temporarily renames the Bluetooth adapter to a recognizable emergency label
 * ONLY while the beacon is actively pulsing during a real alarm.
 * The original device name is saved before the change and restored
 * automatically once the beacon stops, for privacy reasons - so the phone's
 * normal Bluetooth name (used e.g. when pairing with a car) is never
 * permanently altered.
 */
object BluetoothNameManager {

    private const val ALARM_NAME = "SOS QuakeRescue Signal"
    private const val PREFS = "beacon_prefs"
    private const val KEY_SAVED_NAME = "saved_bt_name"

    fun applyAlarmName(context: Context) {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
        try {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val currentName = adapter.name
            if (currentName != null && currentName != ALARM_NAME) {
                prefs.edit().putString(KEY_SAVED_NAME, currentName).apply()
            }
            adapter.name = ALARM_NAME
        } catch (e: SecurityException) { }
    }

    fun restoreOriginalName(context: Context) {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
        try {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val savedName = prefs.getString(KEY_SAVED_NAME, null)
            if (savedName != null) {
                adapter.name = savedName
            }
        } catch (e: SecurityException) { }
    }
}
