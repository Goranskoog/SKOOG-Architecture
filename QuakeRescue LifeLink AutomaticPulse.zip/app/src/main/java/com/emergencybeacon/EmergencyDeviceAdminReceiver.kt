package com.emergencybeacon

import android.app.admin.DeviceAdminReceiver

class EmergencyDeviceAdminReceiver : DeviceAdminReceiver()
