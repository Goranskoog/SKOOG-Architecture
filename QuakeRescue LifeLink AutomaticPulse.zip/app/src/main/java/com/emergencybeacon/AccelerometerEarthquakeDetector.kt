package com.emergencybeacon

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.TriggerEvent
import android.hardware.TriggerEventListener
import android.os.Handler
import android.os.Looper

/**
 * Same two-stage, low-power design used by Google's own earthquake alert
 * network: the app does NOT continuously poll the accelerometer to save
 * battery. Instead:
 *
 * Stage 1 (sleeping, near-zero power): registers with the phone's dedicated
 * TYPE_SIGNIFICANT_MOTION hardware trigger sensor. This sensor lives in its
 * own low-power chip, separate from the main CPU, and stays completely
 * asleep - consuming no meaningful battery - until the phone experiences
 * genuinely large motion. It does not fire for everyday handling, walking,
 * or vibration.
 *
 * Stage 2 (brief confirmation, a few seconds only): only once Stage 1 wakes
 * up does the app briefly turn on the regular accelerometer (SENSOR_DELAY_GAME)
 * for a short confirmation window, to verify this is a real strong shake and
 * not just the phone being picked up or dropped once. If confirmed, the
 * countdown starts. If not confirmed within the window, the accelerometer is
 * unregistered immediately and the system goes back to sleep on Stage 1.
 *
 * If TYPE_SIGNIFICANT_MOTION is unavailable on a given device, the code falls
 * back to a low-frequency accelerometer poll (SENSOR_DELAY_NORMAL) as a
 * safety net - still far lower power than continuous game-speed polling.
 */
object AccelerometerEarthquakeDetector : SensorEventListener {

    private const val CONFIRM_THRESHOLD_G = 3.0
    private const val CONFIRM_WINDOW_MS = 3000L
    private const val REQUIRED_CONFIRM_COUNT = 6

    private var sensorManager: SensorManager? = null
    private var significantSensor: Sensor? = null
    private var accelSensor: Sensor? = null
    private var appContext: Context? = null

    private var stage2Active = false
    private var confirmCount = 0
    private var windowStart = 0L
    private var active = false

    /** Puts the detector into Stage 1 sleep mode: registers the low-power
     * trigger sensor and returns immediately. No continuous sensor reads
     * happen after this call until real motion occurs. */
    fun resume(context: Context) {
        if (active) return
        active = true
        appContext = context.applicationContext
        sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        significantSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_SIGNIFICANT_MOTION)
        accelSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        if (significantSensor != null) {
            // Stage 1: hardware-level trigger sensor, effectively zero
            // ongoing power draw while sleeping.
            sensorManager?.requestTriggerSensor(triggerListener, significantSensor)
        } else {
            // Fallback only for devices without a significant-motion chip.
            accelSensor?.let {
                sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
            }
        }
    }

    /** Fully stops all sensor listening - used while the beacon itself is
     * actively transmitting, since the motion sensor has already done its
     * job and continuing to listen would only waste battery. */
    fun pause() {
        active = false
        stage2Active = false
        sensorManager?.unregisterListener(this)
        sensorManager?.cancelTriggerSensor(triggerListener, significantSensor)
    }

    private val triggerListener = object : TriggerEventListener() {
        override fun onTrigger(event: TriggerEvent) {
            beginStage2Confirmation()
            // Significant motion triggers are one-shot by design - re-arm
            // immediately so the sensor goes back to sleep for the next event.
            sensorManager?.requestTriggerSensor(this, significantSensor)
        }
    }

    private fun beginStage2Confirmation() {
        if (!active) return
        stage2Active = true
        confirmCount = 0
        windowStart = System.currentTimeMillis()
        accelSensor?.let {
            sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        // Hard cutoff: if a real shake isn't confirmed within the window,
        // stop polling the accelerometer and return to Stage 1 sleep.
        Handler(Looper.getMainLooper()).postDelayed({
            if (stage2Active) {
                stage2Active = false
                sensorManager?.unregisterListener(this, accelSensor)
            }
        }, CONFIRM_WINDOW_MS + 200)
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (!active || !stage2Active) return
        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]
        val gForce = Math.sqrt((x * x + y * y + z * z).toDouble()) / SensorManager.GRAVITY_EARTH

        val now = System.currentTimeMillis()
        if (now - windowStart > CONFIRM_WINDOW_MS) {
            windowStart = now
            confirmCount = 0
        }
        if (gForce > CONFIRM_THRESHOLD_G) {
            confirmCount++
            if (confirmCount >= REQUIRED_CONFIRM_COUNT) {
                stage2Active = false
                sensorManager?.unregisterListener(this, accelSensor)
                appContext?.let { ctx -> EarthquakeState.triggerCountdown(ctx, "shake_detection") }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
