package com.emergencybeacon

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WifiManager
import android.provider.Settings

/**
 * Smart screen backlight: invisible when not needed, readable the instant
 * someone finds and picks up the phone during rescue.
 *
 * While the beacon is active and nobody is looking at the phone, brightness
 * is forced down to 1% to save every possible percent of battery for the
 * BLE signal and siren, which matter far more than a screen nobody sees.
 *
 * The moment the screen is turned on or unlocked (ACTION_SCREEN_ON /
 * ACTION_USER_PRESENT) - i.e. a rescuer or the survivor themselves picks up
 * and looks at the phone - brightness is raised to a clearly readable level
 * (not full/maximum brightness, just enough to comfortably read the status
 * text and press the stop button). This costs no extra battery overall,
 * since the screen would otherwise be fully off while the phone lies
 * unattended. As soon as the screen turns off again, brightness drops back
 * to 1% automatically. This readable state is exactly what allows someone
 * to actually see and use the two-stage hold-to-stop control in MainActivity.
 */
object EmergencyPowerManager {
    private var savedBrightness: Int = -1
    private var receiver: BroadcastReceiver? = null
    private const val READABLE_LEVEL = 180

    fun dimScreen(context: Context) {
        try {
            savedBrightness = Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Exception) { }
        forceBrightness(context, 1)
        try {
            @Suppress("DEPRECATION")
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            wifiManager.isWifiEnabled = false
        } catch (e: Exception) { }
        registerScreenListener(context)
    }

    private fun forceBrightness(context: Context, value: Int) {
        try {
            if (Settings.System.canWrite(context)) {
                Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, value)
            }
        } catch (e: Exception) { }
    }

    private fun registerScreenListener(context: Context) {
        if (receiver != null) return
        receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                when (intent.action) {
                    // Screen turned on or unlocked -> someone is looking at
                    // it right now -> raise to readable brightness so the
                    // stop controls can actually be seen and used.
                    Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> forceBrightness(ctx, READABLE_LEVEL)
                    // Screen off again -> nobody looking -> drop back to 1%
                    // to conserve battery for the beacon/siren.
                    Intent.ACTION_SCREEN_OFF -> forceBrightness(ctx, 1)
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        context.applicationContext.registerReceiver(receiver, filter)
    }

    fun restoreScreen(context: Context) {
        try {
            receiver?.let { context.applicationContext.unregisterReceiver(it) }
        } catch (e: Exception) { }
        receiver = null
        try {
            if (savedBrightness >= 0 && Settings.System.canWrite(context)) {
                Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, savedBrightness)
            }
        } catch (e: Exception) { }
    }
}
