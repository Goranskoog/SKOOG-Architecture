package com.emergencybeacon

import android.content.Context
import com.google.android.gms.wearable.Wearable

object WearSyncManager {
    fun notifyWatch(context: Context) {
        try {
            val nodeClient = Wearable.getNodeClient(context)
            val messageClient = Wearable.getMessageClient(context)
            nodeClient.connectedNodes.addOnSuccessListener { nodes ->
                for (node in nodes) {
                    messageClient.sendMessage(node.id, "/quakerescue/activate", ByteArray(0))
                }
            }
        } catch (e: Exception) { }
    }
}
