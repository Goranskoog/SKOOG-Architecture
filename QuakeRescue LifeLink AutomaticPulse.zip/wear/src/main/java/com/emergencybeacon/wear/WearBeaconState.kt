package com.emergencybeacon.wear

object WearBeaconState {
    var isActive: Boolean = false
}
