package com.emergencybeacon.wear

import android.content.Intent
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

class WearMessageListenerService : WearableListenerService() {
    override fun onMessageReceived(event: MessageEvent) {
        if (event.path == "/quakerescue/activate") {
            startService(Intent(this, WearBeaconService::class.java))
        }
    }
}
