package com.emergencybeacon.wear

import android.app.Service
import android.content.Intent
import android.os.CountDownTimer
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator

class WearBeaconService : Service() {
    private var timer: CountDownTimer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        WearBeaconState.isActive = true
        startVibrationCycle()
        return START_STICKY
    }

    private fun startVibrationCycle() {
        vibrate()
        timer = object : CountDownTimer(15 * 60_000L, 15 * 60_000L) {
            override fun onTick(millisUntilFinished: Long) {}
            override fun onFinish() {
                vibrate()
                startVibrationCycle()
            }
        }.start()
    }

    private fun vibrate() {
        val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
        vibrator.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    override fun onDestroy() {
        WearBeaconState.isActive = false
        timer?.cancel()
        super.onDestroy()
    }
}
