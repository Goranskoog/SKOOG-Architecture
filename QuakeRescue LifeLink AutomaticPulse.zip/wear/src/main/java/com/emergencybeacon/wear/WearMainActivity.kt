package com.emergencybeacon.wear

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class WearMainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wear_main)
        findViewById<TextView>(R.id.wearStatusText).text = getString(R.string.wear_ready)
    }
}
